import React, { useState, useEffect } from 'react';
import { Link } from "react-router-dom";
import axios from 'axios';
import './manageEvents.css';
import 'react-datepicker/dist/react-datepicker.css';
import './ListEvents.css';
import EditForm from './editEvent.js';
import homeIcon from '../images/tree.png';

const EventsByUser = () => {
    const [events, setEvents] = useState([]);
    const jwtToken = sessionStorage.getItem("jwt");
    const [showEdit, setShowEdit] = useState(false);
    const [selectedEventId, setSelectedEventId] = useState(null);
    const userId = sessionStorage.getItem("userId");
    const currentDate = new Date();

    const toggleFormVisibility = (eventId) => { 
        setShowEdit(!showEdit);
        setSelectedEventId(eventId); 
    };

    useEffect(() => {
        const fetchEventsByUser = async () => {
            try {
                const response = await axios.get(`http://localhost:8080/events/${userId}/events`,{
                    headers: {
                        Authorization: `Bearer ${jwtToken}` 
                    }
                });
                setEvents(response.data);
            } catch (error) {
                console.error('Error fetching events:', error);
            }
        };
        fetchEventsByUser();
    }, [userId]);

    const handleDeleteEvent = async (eventId) => {
        try {
            await axios.delete(`http://localhost:8080/events/${eventId}`,{
                headers: {
                    Authorization: `Bearer ${jwtToken}`
                }
            });
            setEvents(events.filter(event => event.id !== eventId));
        } catch (error) {
            console.error('Error deleting event:', error);
        }
    };

    const handleMarkAsFinished = async (eventId) => {
        try {
            await axios.put(`http://localhost:8080/events/${eventId}/markFinished`, null, {
                headers: {
                    Authorization: `Bearer ${jwtToken}` 
                }
            });
        } catch (error) {
            console.error('Error marking event as finished:', error);

        }
    };

    return (
        <div className="container">
            {showEdit && <div className="backdrop" onClick={() => toggleFormVisibility(null)}></div>}
            {showEdit && <EditForm onCancel={() => toggleFormVisibility(null)} eventId={selectedEventId} />}
                <div className="event-list">
                    {events.map(event => (
                        <div className="event-item" key={event.id}>
                            <h2>{event.name}</h2>
                            <p className="description"><strong>Description:</strong> {event.description}</p>
                            <p className="hosted-by"><strong>Hosted by:</strong> {event.userName}</p>
                            <p className="location"><strong>Location:</strong> {event.location}</p>
                            <p className="date"><strong>Date:</strong> {event.date ? event.date.substring(0, 10) : 'Not specified'}</p>
                            <p className="slots"><strong>Reserved Slots:</strong> {event.numberOfApplications}/{event.applicationLimit}</p>
                            <p><strong><Link to={`/manageApplications/${event.id}`}>Manage Applications for "{event.name}"</Link></strong></p>
                        
                            <button className="delete-button" onClick={() => handleDeleteEvent(event.id)}>Delete Event</button>

                            {new Date(event.date) < currentDate && (<button className="createevent_button" onClick={() => handleMarkAsFinished(event.id)}>Mark as Finished</button>)}

                            <button className = 'createevent_button' onClick={() => toggleFormVisibility(event.id)}>Edit Event</button>
                            <img className="event-image" src={homeIcon} alt="Event"/>
                        </div>
                    ))}
                </div>
        </div>
    );
};

export default EventsByUser;