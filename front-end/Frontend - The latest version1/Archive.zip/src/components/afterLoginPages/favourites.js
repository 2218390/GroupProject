import React, { useState, useEffect } from 'react';
import axios from 'axios';
import Header from './navbar2.js';
import Footer from '../footer.js';
import './ListEvents.css';
import heart from '../images/heart.png';
import heart1 from '../images/heart1.png';
import homeIcon from '../images/tree.png';

const Favorites = () => {
    const [favoriteEvents, setFavoriteEvents] = useState([]);
    const userId = sessionStorage.getItem("userId");
    const jwtToken = sessionStorage.getItem("jwt");

    useEffect(() => {
        fetchFavoriteEvents();
    }, []);

    const fetchFavoriteEvents = async () => {
        try {
            const response = await axios.get(`http://localhost:8080/${userId}/favorite-events`,{
                headers: {
                    Authorization: `Bearer ${jwtToken}`
                }
            });
            setFavoriteEvents(response.data);
        } catch (error) {
            console.error('Error fetching favorite events:', error);
        }
    };

    const toggleFavorite = async (eventId) => {
        try {
            const isFavorite = favoriteEvents.some(event => event.id === eventId);
            if (isFavorite) {
                await axios.delete(`http://localhost:8080/user/${userId}/events/${eventId}/favorite`,{
                    headers: {
                      Authorization: `Bearer ${jwtToken}`
                    }
                });
                setFavoriteEvents(prev => prev.filter(event => event.id !== eventId));
            } 
        } catch (error) {
            if(error.response.status===400){
                alert("Can't add an own event to 'Favourites'")
            }
            console.error('Error toggling favorite:', error);
        }     
    };

    const handleApplyEvent = async (eventId) => { 
        try {
            const response = await axios.post(`http://localhost:8080/applications/apply/${userId}/${eventId}`, {}, {
                headers: {
                    Authorization: `Bearer ${jwtToken}`
                }
            });
            console.log('Applying for event:', eventId);
            alert("Successfully applied for the event!");
        } catch (error) {
            console.log(error);
            if (error.response && error.response.status === 400) {
                alert(error.response.data);
            }   
        }
    };

    return (
        <div>
            <Header/>
            <h2>Favorite Events</h2>
            <ul>
                <div className="event-list">
                    {favoriteEvents.map(event => (
                        <div className={`event-item ${new Date(event.date) < new Date() ? 'event-past' : ''}`} key={event.id}>
                            <h2>{event.name}</h2>
                            <p className="description"><strong>Description:</strong> {event.description}</p>
                            <p className="hosted-by"><strong>Hosted by:</strong> {event.userName}</p>
                            <p className="location"><strong>Location:</strong> {event.location}</p>
                            <p className="date"><strong>Date:</strong> {event.date ? event.date.substring(0, 10) : 'Not specified'}</p>
                            <p className="slots"><strong>Reserved Slots:</strong> {event.numberOfApplications}/{event.applicationLimit}</p>
                            <button className="apply-button" onClick={() => handleApplyEvent(event.id)}>Apply</button>
                            {new Date(event.date) < new Date() && (<p className="warning">This event has passed.</p>)}
                            <div onClick={() => toggleFavorite(event.id)}>
                                {favoriteEvents.some(favoriteEvent => favoriteEvent.id === event.id) ? <img src={heart1} alt="Heart" /> : <img src={heart} alt="Heart1" />}
                            </div>
                            <img className="event-image" src={homeIcon} alt="Event" />
                        </div>
                    ))}
                </div>
            </ul>
            <Footer/>
        </div>
    );
};
export default Favorites;