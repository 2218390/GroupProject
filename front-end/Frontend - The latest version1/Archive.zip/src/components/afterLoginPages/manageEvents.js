import React from 'react';
import EventsByUser from './eventbyuser.js';
import Header from './navbar2.js';
import Footer from '../footer.js';

const App = () => {
    const userId = sessionStorage.getItem("userId");
    return (
        <div>
            <Header/>
            <h1 className='page-title'>My Hostings</h1>
            <EventsByUser userId={userId} />
            <Footer style={{ marginTop: 'auto' }}/>    
        </div>
    );
};

export default App;