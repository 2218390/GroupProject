import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useParams } from 'react-router-dom';
import Header from './navbar2.js';
import "./myapplications.css"

const ManageApplications = () => {
    const [applications, setApplications] = useState([]);
    const { eventId } = useParams();
    const jwtToken = sessionStorage.getItem("jwt");

    useEffect(() => {
        const fetchApplicationsForEvent = async () => {
            try {
                const response = await axios.get(`http://localhost:8080/applications/${parseInt(eventId, 10)}/applications`,{
                    headers: {
                        Authorization: `Bearer ${jwtToken}`
                    }
                });
                setApplications(response.data);
            } catch (error) {
                console.error('Error fetching applications for event:', error);
            }
        };
        fetchApplicationsForEvent();
    }, [eventId]);

    const handleUpdateStatus = async (applicationId, newStatus) => {
        try {
            await axios.put(`http://localhost:8080/applications/${applicationId}`, { applicationStatus: newStatus },{
                headers: {
                    Authorization: `Bearer ${jwtToken}`
                }
            });
            setApplications(applications.map(application => {
                if (application.id === applicationId) {
                    return { ...application, applicationStatus: newStatus };
                }
                return application;
            }));
        } catch (error) {
            console.error('Error updating application status:', error);
        }
    };

    return (
        <div>
            <Header/>
            <h1 className='page-title'>Your Applications</h1>
            <ul className='myappliedevents-list'>
                {applications.map(application => (
                    <li className='myapp-box'key={application.id}>
                        <p><strong>Applicant Name:</strong> {application.applicantName}</p>
                        <p><strong>Applicant Email:</strong> {application.applicantEmail}</p>
                        <p><strong>Status:</strong> {application.applicationStatus}</p>
                        <select onChange={(e) => handleUpdateStatus(application.id, e.target.value)}>
                            <option value="pending">Pending</option>
                            <option value="accepted">Accepted</option>
                            <option value="rejected">Rejected</option>
                        </select>
                    </li>
                ))}
            </ul>
        </div>
    );
};
export default ManageApplications;